<template>
  <div id="app">
    <h1>Rou Xuan's Restaurant</h1>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  data() {
    return {
    };
  },
};
</script>

<style>
h1 {
  background-color:#f8cac9;
  color:peru;
  text-align: center;
  font-family:'Times New Roman', Times, serif;
  padding: 30px;
}
</style>
